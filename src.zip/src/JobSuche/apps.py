from django.apps import AppConfig


class JobsucheConfig(AppConfig):
    name = 'JobSuche'
