from django.apps import AppConfig


class BoardcurrenciesConfig(AppConfig):
    name = 'Boardcurrencies'
